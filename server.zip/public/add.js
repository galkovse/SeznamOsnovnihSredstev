$(document).ready(function() {
    loadForm();

    $('#submitRow').click(function() {
        const newRow = {};
        $('#addRowForm').serializeArray().forEach(input => {
            newRow[input.name] = input.value;
        });
        addRowToExcel(newRow);
    });
});

function loadForm() {
    $.ajax({
        url: '/data',
        method: 'GET',
        success: function(response) {
            data = response;
            let columns = [];
            if (data.length > 0) {
                columns = Object.keys(data[0]).map(key => ({
                    title: key,
                    data: key,
                    defaultContent: ''
                }));
            }
            populateForm(columns);
        }
    });
}

function populateForm(columns) {
    $('#addRowForm').empty();
    columns.forEach(col => {
        if (col.data !== null) {
            $('#addRowForm').append(`<div class="form-group"><input type="text" class="form-control" name="${col.data}" placeholder="${col.title}"/></div>`);
        }
    });
}

function addRowToExcel(newRow) {
    $.ajax({
        url: '/data',
        method: 'GET',
        success: function(response) {
            const data = response;
            data.push(newRow);
            $.ajax({
                url: '/data',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(data),
                success: function() {
                    alert('Row added successfully!');
                    window.location.href = 'index.html';
                }
            });
        }
    });
}
