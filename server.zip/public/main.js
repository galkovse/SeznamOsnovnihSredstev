let table;
let data;

$(document).ready(function() {
    loadData();

    $('#saveChanges').click(function() {
        const updatedData = table.data().toArray().map((row, index) => {
            delete row['#'];
            return row;
        });
        $.ajax({
            url: '/data',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(updatedData),
            success: function() {
                alert('Data saved successfully!');
                loadData(); // Osveži podatke po shranjevanju
            }
        });
    });

    $('#refreshTable').click(function() {
        loadData();
    });

    $('#startScan').click(function() {
        startQrScanner();
    });

    // Redno osveževanje podatkov
    setInterval(loadData, 30000); // Osveži podatke vsakih 30 sekund

    $('#excelTable tbody').on('dblclick', 'tr', function() {
        const row = table.row(this).data();
        const rowIndex = table.row(this).index();
        editRowInPlace(this, row, rowIndex);
    });
});

function loadData() {
    $.ajax({
        url: '/data',
        method: 'GET',
        success: function(response) {
            data = response;
            initializeTable(data);
        },
        error: function(error) {
            console.error("Napaka pri nalaganju podatkov:", error);
        }
    });
}

function initializeTable(data) {
    let columns = [];
    if (data.length > 0) {
        columns = Object.keys(data[0]).map(key => ({
            title: key,
            data: key,
            defaultContent: ''
        }));
    }

    // Dodaj stolpec za številke vrstic
    columns.unshift({ title: '#', data: null, defaultContent: '', render: (data, type, row, meta) => meta.row + 1 });

    if (table) {
        table.clear().destroy();
        $('#excelTable thead').empty();
    }

    table = $('#excelTable').DataTable({
        data: data,
        columns: columns,
        paging: true, // Omogoči paginacijo
        searching: true, // Omogoči iskanje
        info: true, // Prikaži informacije
        autoWidth: false, // Onemogoči samodejno širino
        responsive: true, // Omogoči responsive design
        order: [[1, 'asc']] // Uredi po prvem stolpcu (številke vrstic)
    });

    table.on('order.dt search.dt', function() {
        table.column(0, { search: 'applied', order: 'applied' }).nodes().each(function(cell, i) {
            cell.innerHTML = i + 1;
        });
    }).draw();
}

function editRowInPlace(rowElement, rowData, rowIndex) {
    $(rowElement).children('td').each(function(index) {
        if (index !== 0) { // Ne spreminjaj prvega stolpca (številka vrstice)
            const key = table.column(index).dataSrc();
            const value = rowData[key];
            $(this).html(`<input type="text" class="form-control" value="${value}"/>`);
        }
    });
    const saveButton = $('<button class="btn btn-success mt-2">Shrani spremembe</button>');
    $(rowElement).after($('<tr><td colspan="' + $(rowElement).children('td').length + '"></td></tr>').find('td').append(saveButton).parent());

    saveButton.click(function() {
        const updatedRow = {};
        $(rowElement).children('td').each(function(index) {
            if (index !== 0) { // Ne spreminjaj prvega stolpca (številka vrstice)
                const key = table.column(index).dataSrc();
                const value = $(this).find('input').val();
                updatedRow[key] = value;
                $(this).html(value);
            } else {
                $(this).html(rowIndex + 1);
            }
        });

        table.row(rowIndex).data($.extend({}, rowData, updatedRow)).draw();
        saveButton.closest('tr').remove();
    });
}

function startQrScanner() {
    const html5QrCode = new Html5Qrcode("qr-reader");
    html5QrCode.start(
        { facingMode: "environment" },
        {
            fps: 10,
            qrbox: 250
        },
        qrCodeMessage => {
            $('#qr-result').text(`QR Code: ${qrCodeMessage}`);
            findComputerByCode(qrCodeMessage);
            html5QrCode.stop().then(() => {
                console.log("QR code scanning stopped.");
            }).catch(err => {
                console.error("Unable to stop scanning.", err);
            });
        },
        errorMessage => {
            console.error("QR Code no match.", errorMessage);
        }
    ).catch(err => {
        console.error("Unable to start scanning.", err);
    });
}

function findComputerByCode(code) {
    const computer = data.find(row => row.Code === code); // Predpostavljamo, da je stolpec ime "Code"
    if (computer) {
        alert(`Computer found: ${JSON.stringify(computer)}`);
    } else {
        alert('Computer not found');
    }
}
